
.. _constrain.ConstraintsIntersection:

.. |Constraint| replace:: ConstraintsIntersection

Constraints intersection
------------------------

.. autoclass:: pyasn1.type.constraint.ConstraintsIntersection(*constraints)
   :members:
